(function () {
  'use strict';

  angular.module('app.create', ['ml.common', 'app.user']);
}());
